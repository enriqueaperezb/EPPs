﻿using EPPs.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Data;
using System.Diagnostics;
using System.Reflection;

namespace EPPs.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _config;
        private readonly ILogger<HomeController> _logger;
        private readonly IWebHostEnvironment _env; // <-- NUEVO

        private string? _codigo_nef;          //Nivel del centro de costo
        private string? _codigo_epi_aprobado; //Estado previo inventario
        private string? _codigo_epi_anulado;  //Estado previo inventario
        private string? _codigo_usu_aprueba;  //Usuario
        private string? _codigo_tti_consumo;  //Tipo de comprobante de inventario

        public HomeController(IConfiguration config, ILogger<HomeController> logger, IWebHostEnvironment env)
        {
            _config = config;
            _logger = logger;
            _env = env; // <-- NUEVO            
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            SetVarsEmpresaFromCookie(); // ← lee cookie y setea _empresaActual, _connName, etc.
            base.OnActionExecuting(context);
        }

        [HttpGet]
        public async Task<IActionResult> Index(string? codigo_emp, bool reset = false)
        {
            if (reset)
            {
                ViewBag.Codigo_emp = "";
                ViewBag.NombreEmpleado = "";
                ViewBag.Empresa = Request.Cookies["empresa"] ?? "";
                return View(new List<previoInventario>()); // ← sin datos
            }

            var resultados = new List<previoInventario>();
            var connStr = _config.GetConnectionString("DefaultConnection");

            // EJEMPLO de consulta: ajusta nombres de tabla/columnas a tu base
            const string sql = @"
                SELECT
                    dbo.i_cab_prev_inve.codigo_cpi codigo,
                    dbo.i_cab_prev_inve.fecha_elabo_cpi fecha,
                    ISNULL(dbo.i_cab_prev_inve.observacion_cpi,'') observacion
                FROM
                    dbo.i_cab_prev_inve
                WHERE 
                    (dbo.i_cab_prev_inve.codigo_emp LIKE @codigo_emp) AND
                    (dbo.i_cab_prev_inve.codigo_epi not like @codigo_epi) AND
                    (dbo.i_cab_prev_inve.observacion_cpi LIKE 'EPP%') 
                    AND dbo.i_cab_prev_inve.codigo_tti LIKE @codigo_tti
                ORDER BY 
                    dbo.i_cab_prev_inve.codigo_cpi DESC;";

            await using var conn = new SqlConnection(connStr);
            await conn.OpenAsync();

            await using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add(new SqlParameter("@codigo_emp", SqlDbType.NVarChar, 200) { Value = (object?)codigo_emp ?? DBNull.Value });
                cmd.Parameters.Add(new SqlParameter("@codigo_epi", SqlDbType.NVarChar, 200) { Value = (object?)_codigo_epi_aprobado ?? DBNull.Value });
                cmd.Parameters.Add(new SqlParameter("@codigo_tti", SqlDbType.NVarChar, 200) { Value = (object?)_codigo_tti_consumo ?? DBNull.Value });
                await using var rdr = await cmd.ExecuteReaderAsync();
                while (await rdr.ReadAsync())
                {
                    resultados.Add(new previoInventario
                    {
                        Codigo = rdr.GetString(0),
                        Fecha = rdr.GetDateTime(1),
                        Observacion = rdr.GetString(2)
                    });
                }
            }

            // 2) Nombre del empleado (para mostrar bajo el input)
            string nombreEmpleado = "";
            if (!string.IsNullOrWhiteSpace(codigo_emp))
            {
                const string sqlNombre = @"
                    SELECT TOP (1) 
                        dbo.r_empleado.apellido_emp + ' ' + dbo.r_empleado.nombre_emp
                    FROM 
                        dbo.r_empleado 
                    WHERE 
                        dbo.r_empleado.codigo_emp = @codigo_emp;";

                await using var cmd2 = new SqlCommand(sqlNombre, conn);
                cmd2.Parameters.Add(new SqlParameter("@codigo_emp", SqlDbType.NVarChar, 200) { Value = codigo_emp });
                var obj = await cmd2.ExecuteScalarAsync();
                nombreEmpleado = obj as string ?? "";
            }

            ViewBag.Codigo_emp = codigo_emp; // para rellenar el input en la vista
            // Nuevo: el nombre a mostrar bajo el campo de código
            ViewBag.NombreEmpleado = nombreEmpleado;

            // Lee cookie de empresa para preseleccionar en la vista
            var empresaCookie = Request.Cookies["empresa"];
            ViewBag.Empresa = empresaCookie ?? "";

            return View(resultados);
        }

        [HttpGet]
        public async Task<IActionResult> previoInventario_detalle(string codigo_cpi)
        {
            var detalles = new List<previoInventario_detalle>();
            var articulos = new List<SelectListItem>();
            var connStr = _config.GetConnectionString("DefaultConnection");

            const string sqlDetalles = @"
                SELECT 
                    dbo.i_det_prev_inve.codigo_dpv codigo,
                    dbo.c_articulo.codigo_art codigo_art,
                    dbo.c_articulo.nombre_art articulo,
                    dbo.i_det_prev_inve.cantidad_dpv cantidad,
                    dbo.i_det_prev_inve.codigo_efc
                FROM 
                    dbo.i_det_prev_inve INNER JOIN
                    dbo.c_articulo ON dbo.i_det_prev_inve.codigo_art = dbo.c_articulo.codigo_art
                WHERE 
                    dbo.i_det_prev_inve.codigo_cpi = @codigo_cpi
                ORDER BY 
                    dbo.c_articulo.nombre_art;";

            const string sqlArticulos = @"
                SELECT 
                    codigo_art, nombre_art
                FROM 
                    dbo.c_articulo
                ORDER BY 
                    nombre_art;";

            await using var conn = new SqlConnection(connStr);
            await conn.OpenAsync();

            // Detalles
            await using (var cmd = new SqlCommand(sqlDetalles, conn))
            {
                cmd.Parameters.Add(new SqlParameter("@codigo_cpi", SqlDbType.NVarChar, 50) { Value = codigo_cpi });
                await using var rdr = await cmd.ExecuteReaderAsync();
                while (await rdr.ReadAsync())
                {
                    detalles.Add(new previoInventario_detalle
                    {
                        Codigo = rdr.GetString(0),
                        CodigoArticulo = rdr.GetString(1),   // <-- Nuevo, se llena el código
                        Articulo = rdr.GetString(2),
                        Cantidad = rdr.GetDecimal(3),
                        CodigoCentroCosto = rdr.IsDBNull(4) ? null : rdr.GetString(4)
                    });
                }
            }

            // Artículos
            await using (var cmd2 = new SqlCommand(sqlArticulos, conn))
            await using (var rdr2 = await cmd2.ExecuteReaderAsync())
            {
                while (await rdr2.ReadAsync())
                {
                    articulos.Add(new SelectListItem
                    {
                        Value = rdr2.GetString(0), // codigo_art
                        Text = rdr2.GetString(1)   // nombre_art
                    });
                }
            }

            const string sqlEfc = @"SELECT codigo_efc, nombre_efc FROM dbo.d_est_fisi_cost WHERE codigo_nef = '00102' ORDER BY nombre_efc;";
            var centros = new List<SelectListItem>();

            await using (var cmd3 = new SqlCommand(sqlEfc, conn))
            //cmd3.Parameters.Add(new SqlParameter("@codigo_nef", SqlDbType.NVarChar, 200) { Value = (object?)_codigo_nef ?? DBNull.Value });
            await using (var r3 = await cmd3.ExecuteReaderAsync())
            {
                while (await r3.ReadAsync())
                {
                    centros.Add(new SelectListItem
                    {
                        Value = r3.GetString(0),
                        Text = r3.GetString(1)
                    });
                }
            }
            var vm = new previoInventario_detalleListado
            {
                Detalles = detalles,
                Articulos = articulos,
                CentrosCosto = centros
            };

            return PartialView("_previoInventario_detalle", vm);
        }

        private static string SanitizarNombreArchivo(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre)) return "empleado";
            // Reemplaza espacios por _
            var s = nombre.Trim().Replace(' ', '_');

            // Quita caracteres inválidos de nombre de archivo
            foreach (var c in Path.GetInvalidFileNameChars())
                s = s.Replace(c.ToString(), "");

            return s;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GuardarPrevioDetalle([FromBody] GuardarDetallePrevioInventario req)
        {
            if (req == null) return BadRequest("Petición vacía.");

            var connStr = _config.GetConnectionString("DefaultConnection");

            const string SQL_UPD_DET = @"
                UPDATE 
                    dbo.i_det_prev_inve
                SET 
                    codigo_art = @codigo_art,
                    cantidad_dpv = @cantidad,
                    canti_pedid_dpv = @cantidad,
                    codigo_efc = @codigo_efc
                WHERE 
                    codigo_dpv = @codigo_dpv;";

            const string SQL_INS_DET = @"
                INSERT INTO 
                    dbo.i_det_prev_inve (codigo_cpi, codigo_dpv, codigo_art, cantidad_dpv, canti_pedid_dpv, precio_dpv, codigo_efc)
                VALUES 
                    (@codigo_cpi, (SELECT '00'+CONVERT(VARCHAR,MAX_NUM_BLO+1) FROM S_BLOQUEO WHERE TABLA_BLO LIKE 'i_det_prev_inve'), @codigo_art, @cantidad, @cantidad, 0, @codigo_efc);

                UPDATE S_BLOQUEO SET MAX_NUM_BLO=MAX_NUM_BLO+1 FROM S_BLOQUEO WHERE TABLA_BLO LIKE 'i_det_prev_inve';";

            // 1) Normaliza colecciones
            var itemsSel = req.Items ?? new List<ItemCambio>();
            var codigosAll = req.TodosCodigos ?? new List<string>();
            var nuevos = req.Nuevos ?? new List<ItemCambio>();

            // 2) Regla de estado
            //    - Si NO hay seleccionados NI nuevos => 0012 (no borrar nada)
            //    - Si hay seleccionados o nuevos    => 0011 (y se borran los no seleccionados)
            var haySeleccion = (itemsSel.Count + nuevos.Count) > 0;
            var estadoEpi = haySeleccion ? "00103" : "00105";

            int updated = 0, inserted = 0, deleted = 0, headersUpdated = 0;

            await using var cn = new SqlConnection(connStr);
            await cn.OpenAsync();
            await using var tx = await cn.BeginTransactionAsync();

            // Preparamos lista de cabeceros involucrados (a partir de lo visible)
            var headerIds = new List<string>();
            try
            {
                if (codigosAll.Count > 0)
                {
                    var inParams = string.Join(",", codigosAll.Select((_, i) => $"@cd{i}"));
                    var sqlHdr = $@"
                        SELECT 
                            DISTINCT d.codigo_cpi
                        FROM 
                            dbo.i_det_prev_inve AS d
                        WHERE 
                            d.codigo_dpv IN ({inParams});";

                    await using (var cmdHdr = new SqlCommand(sqlHdr, cn, (SqlTransaction)tx))
                    {
                        for (int i = 0; i < codigosAll.Count; i++)
                            cmdHdr.Parameters.Add(new SqlParameter($"@cd{i}", SqlDbType.NVarChar, 50) { Value = codigosAll[i] });

                        await using var rdr = await cmdHdr.ExecuteReaderAsync();
                        while (await rdr.ReadAsync())
                            headerIds.Add(rdr.GetString(0));
                    }
                }

                // 3) INSERT nuevos (requiere codigo_cpi)
                if (nuevos.Count > 0)
                {
                    if (string.IsNullOrWhiteSpace(req.CodigoCpi))
                        return BadRequest("Falta codigo_cpi para insertar nuevas líneas.");

                    foreach (var n in nuevos)
                    {
                        await using var cmdIns = new SqlCommand(SQL_INS_DET, cn, (SqlTransaction)tx);
                        cmdIns.Parameters.Add(new SqlParameter("@codigo_cpi", SqlDbType.NVarChar, 50) { Value = req.CodigoCpi });
                        cmdIns.Parameters.Add(new SqlParameter("@codigo_art", SqlDbType.NVarChar, 50) { Value = (object?)n.CodigoArticulo ?? DBNull.Value });

                        var pCant = cmdIns.Parameters.Add("@cantidad", SqlDbType.Decimal);
                        pCant.Precision = 22; pCant.Scale = 15;
                        pCant.Value = n.Cantidad;
                        cmdIns.Parameters.Add(new SqlParameter("@codigo_efc", SqlDbType.NVarChar, 50) { Value = (object?)n.CodigoCentroCosto ?? DBNull.Value });

                        inserted += await cmdIns.ExecuteNonQueryAsync() - 1;
                    }
                }

                // 4) UPDATE seleccionados
                foreach (var it in itemsSel)
                {
                    await using var cmdUp = new SqlCommand(SQL_UPD_DET, cn, (SqlTransaction)tx);
                    cmdUp.Parameters.Add(new SqlParameter("@codigo_art", SqlDbType.NVarChar, 50) { Value = (object?)it.CodigoArticulo ?? DBNull.Value });

                    var pCant = cmdUp.Parameters.Add("@cantidad", SqlDbType.Decimal);
                    pCant.Precision = 22; pCant.Scale = 15;
                    pCant.Value = it.Cantidad;

                    cmdUp.Parameters.Add(new SqlParameter("@codigo_dpv", SqlDbType.NVarChar, 50) { Value = it.Codigo });
                    cmdUp.Parameters.Add(new SqlParameter("@codigo_efc", SqlDbType.NVarChar, 50) { Value = (object?)it.CodigoCentroCosto ?? DBNull.Value });
                    
                    updated += await cmdUp.ExecuteNonQueryAsync();
                }

                // 5) DELETE no seleccionados (solo si hay selección)
                if (haySeleccion && codigosAll.Count > 0)
                {
                    var setSel = new HashSet<string>(itemsSel.Select(x => x.Codigo));
                    // si agregaste nuevos con código fijo, no estarán en codigosAll hasta que recargues desde BD,
                    // así que el delete no los tocará (correcto).
                    var paraEliminar = codigosAll.Where(c => !setSel.Contains(c)).ToList();
                    if (paraEliminar.Count > 0)
                    {
                        var inDel = string.Join(",", paraEliminar.Select((_, i) => $"@del{i}"));
                        var sqlDel = $"DELETE FROM dbo.i_det_prev_inve WHERE codigo_dpv IN ({inDel});";

                        await using var cmdDel = new SqlCommand(sqlDel, cn, (SqlTransaction)tx);
                        for (int i = 0; i < paraEliminar.Count; i++)
                            cmdDel.Parameters.Add(new SqlParameter($"@del{i}", SqlDbType.NVarChar, 50) { Value = paraEliminar[i] });

                        deleted = await cmdDel.ExecuteNonQueryAsync();
                    }
                }

                // 6) Actualizar estado de cabecero(s) (0011/0012)
                if (headerIds.Count > 0)
                {
                    var inHdr = string.Join(",", headerIds.Select((_, i) => $"@h{i}"));
                    var sqlUpdHdr = $@"
                        UPDATE 
                            dbo.i_cab_prev_inve
                        SET 
                            codigo_epi = @epi,
                            s_u_codigo_usu = '004',
                            obser_tribu_cpi = 'Documento actualizado desde Tablet el ' + convert(varchar,getdate()) 
                        WHERE 
                            codigo_cpi IN ({inHdr});";

                    await using var cmdHdrUpd = new SqlCommand(sqlUpdHdr, cn, (SqlTransaction)tx);
                    cmdHdrUpd.Parameters.Add(new SqlParameter("@epi", SqlDbType.NVarChar, 10) { Value = estadoEpi });
                    for (int i = 0; i < headerIds.Count; i++)
                        cmdHdrUpd.Parameters.Add(new SqlParameter($"@h{i}", SqlDbType.NVarChar, 50) { Value = headerIds[i] });

                    headersUpdated = await cmdHdrUpd.ExecuteNonQueryAsync();
                }

                // ------------------------------------------------------------------
                // GUARDAR FOTO (si llegó) + ACTUALIZAR pdf_normal_cpi en cabecera
                // ------------------------------------------------------------------
                string? fotoPathRel = null;

                if (!string.IsNullOrWhiteSpace(req.FotoBase64) && !string.IsNullOrWhiteSpace(req.CodigoCpi))
                {
                    // 2.1 Obtener nombre del empleado por codigo_cpi
                    string nombreEmpleado = "empleado";
                    const string SQL_EMPLEADO = @"
                        SELECT TOP (1) 
                            emp.apellido_emp + ' ' + emp.nombre_emp
                        FROM 
                            dbo.i_cab_prev_inve cpi
                            INNER JOIN dbo.r_empleado emp ON emp.codigo_emp = cpi.codigo_emp
                        WHERE 
                            cpi.codigo_cpi = @codigo_cpi;";

                    await using (var cmdEmp = new SqlCommand(SQL_EMPLEADO, cn, (SqlTransaction)tx))
                    {
                        cmdEmp.Parameters.Add(new SqlParameter("@codigo_cpi", SqlDbType.NVarChar, 50) { Value = req.CodigoCpi });
                        var obj = await cmdEmp.ExecuteScalarAsync();
                        if (obj is string s && !string.IsNullOrWhiteSpace(s)) nombreEmpleado = s;
                    }

                    // 2.2 Armar nombre de archivo: NombreEmpleado_sin_espacios + "_" + codigo_cpi + ".jpg"
                    var fileSafeName = $"{SanitizarNombreArchivo(nombreEmpleado)}_{req.CodigoCpi}.jpg";

                    // 2.3 Decodificar base64 y guardar en wwwroot/uploads/fotos/
                    var base64 = req.FotoBase64!;
                    var commaIdx = base64.IndexOf(',');
                    if (commaIdx > 0) base64 = base64[(commaIdx + 1)..];

                    var bytes = Convert.FromBase64String(base64);

                    var webRoot = _env.WebRootPath ?? Path.Combine(AppContext.BaseDirectory, "wwwroot");
                    var folder = Path.Combine(webRoot, "uploads", "fotos");
                    Directory.CreateDirectory(folder);

                    var fullPath = Path.Combine(folder, fileSafeName);
                    await System.IO.File.WriteAllBytesAsync(fullPath, bytes);

                    // 2.4 Path relativo para servir estático
                    fotoPathRel = $"/uploads/fotos/{fileSafeName}";

                    // 2.5 Actualizar i_cab_prev_inve.pdf_normal_cpi con el path
                    const string SQL_UPD_PDF = @"
                        UPDATE 
                            dbo.i_cab_prev_inve
                        SET 
                            pdf_normal_cpi = '\\10.39.10.30\EPPs\wwwroot' + REPLACE(@ruta, '/', '\')
                        WHERE 
                            codigo_cpi = @codigo_cpi;";

                    await using (var cmdPdf = new SqlCommand(SQL_UPD_PDF, cn, (SqlTransaction)tx))
                    {
                        cmdPdf.Parameters.Add(new SqlParameter("@ruta", SqlDbType.NVarChar, 500) { Value = (object)fotoPathRel ?? DBNull.Value });
                        cmdPdf.Parameters.Add(new SqlParameter("@codigo_cpi", SqlDbType.NVarChar, 50) { Value = req.CodigoCpi! });
                        await cmdPdf.ExecuteNonQueryAsync();
                    }
                }

                await tx.CommitAsync();

                // Guardar foto (si llegó)
                try
                {
                    if (!string.IsNullOrWhiteSpace(req.FotoBase64))
                    {
                        // req.FotoBase64 puede venir como "data:image/jpeg;base64,AAAA..."
                        var base64 = req.FotoBase64!;
                        var commaIdx = base64.IndexOf(',');
                        if (commaIdx > 0) base64 = base64[(commaIdx + 1)..];

                        var bytes = Convert.FromBase64String(base64);
                        var folder = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", "fotos");
                        Directory.CreateDirectory(folder);

                        var fileName = $"foto_{(req.CodigoCpi ?? "NA")}_{DateTime.UtcNow:yyyyMMddHHmmss}.jpg";
                        var fullPath = Path.Combine(folder, fileName);
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);

                        fotoPathRel = $"/uploads/fotos/{fileName}";
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error guardando foto");
                }

                // >>> Un único return con el resumen (el front muestra un solo alert)
                return Ok(new
                {
                    updated,
                    inserted,
                    deleted,
                    headersUpdated,
                    estado = estadoEpi,
                    foto = fotoPathRel
                });
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                _logger.LogError(ex, "Error en GuardarPrevioDetalle");
                return StatusCode(500, "Error al guardar los cambios.");
            }
        }


        [HttpGet]
        public async Task<IActionResult> HistorialArticulo(string codigoEmp, string q)
        {
            if (string.IsNullOrWhiteSpace(codigoEmp) || string.IsNullOrWhiteSpace(q))
                return Json(Array.Empty<object>());

            var cs = _config.GetConnectionString("DefaultConnection");
            // Filtrar por los últimos 12 meses y artículos cuyo nombre empiece por "q"
            const string sql = @"
                SELECT TOP (200)
                    c.fecha_elabo_cpi,
                    a.nombre_art,
                    d.cantidad_dpv
                FROM 
                    dbo.i_det_prev_inve AS d
                    INNER JOIN dbo.i_cab_prev_inve AS c ON c.codigo_cpi = d.codigo_cpi
                    INNER JOIN dbo.c_articulo AS a ON a.codigo_art = d.codigo_art 
                    --INNER JOIN dbo.i_det_comp_inve as i ON i.codigo_dpv = d.codigo_dpv -- Solo articulos del previo entregados ojo
                WHERE c.codigo_epi = @codigo_epi
                    AND c.observacion_cpi LIKE 'EPP%'
                    AND c.codigo_tti = @codigo_tti
                    AND c.codigo_emp = @emp
                    AND a.nombre_art LIKE @pat
                    AND c.fecha_elabo_cpi >= DATEADD(MONTH, -12, GETDATE())
                ORDER BY 
                    c.fecha_elabo_cpi DESC;";

            var list = new List<object>();

            await using var cn = new SqlConnection(cs);
            await cn.OpenAsync();
            await using var cmd = new SqlCommand(sql, cn);
            cmd.Parameters.Add(new SqlParameter("@emp", SqlDbType.NVarChar, 50) { Value = codigoEmp });
            cmd.Parameters.Add(new SqlParameter("@pat", SqlDbType.NVarChar, 200) { Value = q + "%" });
            cmd.Parameters.Add(new SqlParameter("@codigo_epi", SqlDbType.NVarChar, 200) { Value = (object?)_codigo_epi_aprobado ?? DBNull.Value });
            cmd.Parameters.Add(new SqlParameter("@codigo_tti", SqlDbType.NVarChar, 200) { Value = (object?)_codigo_tti_consumo ?? DBNull.Value });

            await using var rdr = await cmd.ExecuteReaderAsync();
            while (await rdr.ReadAsync())
            {
                var fecha = rdr.GetDateTime(0).ToString("yyyy-MM-dd");
                var nombre = rdr.GetString(1);
                var cantidad = rdr.GetDecimal(2);
                list.Add(new { fecha, nombre, cantidad });
            }

            return Json(list);
        }

        private void SetVarsEmpresaFromCookie()
        {
            var emp = Request?.Cookies["empresa"] ?? "";

            // Mapea SIEMPRE a una lista blanca (nunca uses el cookie directo en SQL)
            switch (emp)
            {
                case "Bellarosa":
                    _codigo_nef = "00102";          //Nivel del centro de costo
                    _codigo_epi_aprobado = "00103"; //Estado previo inventario
                    _codigo_epi_anulado = "00105";  //Estado previo inventario
                    _codigo_usu_aprueba = "004";  //Usuario
                    _codigo_tti_consumo = "001029";  //Tipo de comprobante de inventario
                    break;
                case "Qualisa":
                    _codigo_nef = "00102";          //Nivel del centro de costo
                    _codigo_epi_aprobado = "00103"; //Estado previo inventario
                    _codigo_epi_anulado = "00105";  //Estado previo inventario
                    _codigo_usu_aprueba = "004";  //Usuario
                    _codigo_tti_consumo = "001029";  //Tipo de comprobante de inventario
                    break;
                case "Royal Flowers":
                    _codigo_nef = "00102";          //Nivel del centro de costo
                    _codigo_epi_aprobado = "00103"; //Estado previo inventario
                    _codigo_epi_anulado = "00105";  //Estado previo inventario
                    _codigo_usu_aprueba = "004";  //Usuario
                    _codigo_tti_consumo = "001029";  //Tipo de comprobante de inventario
                    break;
                case "Sisapamba":
                    _codigo_nef = "00102";          //Nivel del centro de costo
                    _codigo_epi_aprobado = "00103"; //Estado previo inventario
                    _codigo_epi_anulado = "00105";  //Estado previo inventario
                    _codigo_usu_aprueba = "004";  //Usuario
                    _codigo_tti_consumo = "001029";  //Tipo de comprobante de inventario
                    break;
                case "Continental Logistics":
                    _codigo_nef = "00102";          //Nivel del centro de costo
                    _codigo_epi_aprobado = "00103"; //Estado previo inventario
                    _codigo_epi_anulado = "00105";  //Estado previo inventario
                    _codigo_usu_aprueba = "004";  //Usuario
                    _codigo_tti_consumo = "001029";  //Tipo de comprobante de inventario
                    break;
                default:
                    _codigo_nef = "";          //Nivel del centro de costo
                    _codigo_epi_aprobado = ""; //Estado previo inventario
                    _codigo_epi_anulado = "";  //Estado previo inventario
                    _codigo_usu_aprueba = "";  //Usuario
                    _codigo_tti_consumo = "";  //Tipo de comprobante de inventario
                    break;
            }
        }

    }
}



