﻿namespace EPPs.Models
{
    public class previoInventario
    {
        public string Codigo { get; set; }      
        public DateTime Fecha { get; set; }  
        public string Observacion { get; set; }   
    }
}
